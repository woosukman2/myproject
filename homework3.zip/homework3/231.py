
str = "비트코인"

def print_coin():
    print(str)

for i in range(100):
    print_coin()