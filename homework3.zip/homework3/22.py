license_plate = "24가 2210"

print(license_plate[4:])