s = "hello"
t = "python"

print(s)
print(t)
