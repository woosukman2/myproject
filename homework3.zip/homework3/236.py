def message() :
    print("A")
    print("B")

message()
print("C")
message()