my_list = ["가", "나", "다", "라"]

for one_line in my_list[1:]:
    print(one_line)

