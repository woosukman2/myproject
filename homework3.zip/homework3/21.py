lang = 'python'

print(lang[0],lang[2])