phone_number = "010-1111-2222"

print(phone_number.replace("-"," "))