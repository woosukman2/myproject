for 변수 in ["사과", "귤", "수박"]:
    print(변수)
print("--")