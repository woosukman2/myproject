lang1 = ["C", "C++", "JAVA"]
lang2 = ["Python", "Go", "C#"]

set1 = set(lang1)
set2 = set(lang2)

print(set2.union(set1))