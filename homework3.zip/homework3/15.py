t1 = 'python'
t2 = 'java'

print(( t1+t2)*3)
