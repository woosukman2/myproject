# num = int(input())
# num_add = num+20
#
# if num_add > 255:
#     num_add = 255
#
#
# print(num_add)
#

num = int(input("입력하실 숫자: "))
print("출력값:",min(num+20,255))

