portfolio = ["SK하이닉스", "삼성전자", "LG전자"]

for stock in portfolio:
    print(stock,"보유중",    "대박났음")
