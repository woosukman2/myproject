a = "132"
print (type(a))

