# for 변수 in ["사과", "귤", "수박"]:
#     print(변수)

fruit = ["사과", "귤", "수박"]

def fruit_cycle(fruit_var):
    for 변수 in fruit_var:
        print(변수)

fruit_cycle(fruit)

