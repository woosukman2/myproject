print("A")

def message() :
    print("B")

print("C")
message()
