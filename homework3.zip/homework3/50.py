nums = [1, 2, 3, 4, 5]

def average(list):
    return sum(list) / len(list)

print("평균값 : {}".format(average(nums)));