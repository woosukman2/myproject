user_in = int(input())
if user_in % 2 == 0:
    print("짝수")
else:
    print("홀수")
