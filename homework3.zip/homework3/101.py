user_data = str(input())
print(user_data*2)
